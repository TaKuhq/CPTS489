# code-09-09
Contains the SpeedScore Repo updated with an About Box and TestCafe test fixture
This repo serves as the starting point for Chapter 6.
